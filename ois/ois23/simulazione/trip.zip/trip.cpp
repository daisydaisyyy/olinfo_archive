/*
 * This template is valid both in C and in C++,
 * so you can expand it with code from both languages.
 */

#include <stdio.h>
#include <assert.h>

// constraints
#define MAXN 50000
#define MAXM 100000

// input data
int N, M;
int source, destination;

int main() {
//  uncomment the following lines if you want to read/write from files
//  freopen("input.txt", "r", stdin);
//  freopen("output.txt", "w", stdout);

    assert(1 == scanf("%d", &N));
    assert(2 == scanf("%d%d", &source, &destination));
    assert(1 == scanf("%d", &M));
    for (int i=0; i<M; i++) {
        int city1, time1, city2, time2;
        assert(4 == scanf("%d%d%d%d", &city1, &time1, &city2, &time2));

        // insert your code here
    }

    // insert more code here
    
    printf("%d\n", 42); // change 42 with actual answer
    return 0;
}
