#!/usr/bin/env python3
# NOTE: it is recommended to use this even if you don't understand the following code.


# input data
N, D = list(map(int, input().strip().split()))
L = [0 for _ in range(N)]
P = [0 for _ in range(N)]
S = [0 for _ in range(N)]
T = [0 for _ in range(N)]
for i in range(N):
    L[i], P[i], S[i], T[i] = list(map(int, input().strip().split()))


# insert your code here


print(42)  # print the result
