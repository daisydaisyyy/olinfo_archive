/*
 * NOTE: it is recommended to use this even if you don't
 * understand the following code.
 */

#include <iostream>
#include <string>

using namespace std;

// input data
int N, L, K;
string trigram;

int main() {
//  uncomment the following lines if you want to read/write from files
//  freopen("input.txt", "r", stdin);
//  freopen("output.txt", "w", stdout);

    cin >> N >> L >> K;
    for (int i=0; i<K; i++) {
        cin >> trigram;

        // insert your code here
    }

    // insert your code here
    
    cout << "42" << endl; // print the result
    return 0;
}
