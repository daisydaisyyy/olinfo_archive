#!/usr/bin/env python3
# NOTE: it is recommended to use this even if you don't understand the following code.


# input data
N = int(input().strip())
S = [None] * N
P = [None] * N
for i in range(N):
    S[i], P[i] = map(int, input().strip().split())


# insert your code here


print(42)  # print the result
