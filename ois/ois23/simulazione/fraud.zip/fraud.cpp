/*
 * This template is valid both in C and in C++,
 * so you can expand it with code from both languages.
 * NOTE: it is recommended to use this even if you don't
 * understand the following code.
 */

#include <iostream>
#include <vector>

// constraints
#define MAXN 100000

using namespace std;

// input data
int N;
vector<int> V;

int main() {
//  uncomment the following lines if you want to read/write from files
//  freopen("input.txt", "r", stdin);
//  freopen("output.txt", "w", stdout);

    cin >> N;
    V.resize(N);
    for (int i=0; i<N; i++) cin >> V[i];

    // insert your code here
    
    cout << 42 << endl; // print the result
    return 0;
}
